package Ticket;
import java.util.*;
public class Mainclass  {

	public static void main(String[] args) throws Exception
	{
	
		operation A=new operation();
         A.show();
	
	}

}
